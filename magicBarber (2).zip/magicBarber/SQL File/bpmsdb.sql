-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2022 at 04:45 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bpmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` char(50) DEFAULT NULL,
  `UserName` char(50) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Ipfi Tshiswaise', 'ipfiipfi', 793571494, 'Tshiswaise26@gmail.com', '7fc6152df0e4329fc81dfa470ef72473', '2022-05-25 06:21:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblbook`
--

CREATE TABLE `tblbook` (
  `ID` int(10) NOT NULL,
  `UserID` int(10) DEFAULT NULL,
  `AptNumber` int(10) DEFAULT NULL,
  `AptDate` date DEFAULT NULL,
  `AptTime` time DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `BookingDate` timestamp NULL DEFAULT current_timestamp(),
  `Remark` varchar(250) DEFAULT NULL,
  `Status` varchar(250) DEFAULT NULL,
  `RemarkDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbook`
--

INSERT INTO `tblbook` (`ID`, `UserID`, `AptNumber`, `AptDate`, `AptTime`, `Message`, `BookingDate`, `Remark`, `Status`, `RemarkDate`) VALUES
(10, 12, 587849457, '2022-10-14', '00:46:00', 'sG', '2022-10-12 22:43:50', 'R57', 'Selected', '2022-10-13 11:23:21'),
(12, 12, 661072041, '2022-10-15', '16:40:00', 'ipfi', '2022-10-12 22:44:50', 'Dreadlocks', 'Selected', '2022-10-30 08:59:52'),
(13, 14, 645936621, '2022-10-14', '15:47:00', 'sgrd', '2022-10-13 12:47:01', 'R500', 'Rejected', '2022-10-13 12:48:47'),
(14, 14, 840973692, '2022-10-15', '13:31:00', 'lhfgihjpk[]l[p', '2022-10-14 09:29:32', 'los', 'Selected', '2022-10-30 12:44:17'),
(15, 14, 957833775, '2022-10-18', '21:53:00', '', '2022-10-17 05:52:03', NULL, NULL, NULL),
(16, 14, 664122061, '2022-10-18', '21:53:00', '', '2022-10-17 05:52:57', NULL, NULL, NULL),
(17, 14, 884136586, '2022-10-19', '10:45:00', '', '2022-10-18 05:43:31', NULL, NULL, NULL),
(18, 14, 153081094, '2022-10-21', '17:56:00', '', '2022-10-20 11:54:06', NULL, NULL, NULL),
(19, 14, 984371436, '2022-10-26', '17:40:00', '', '2022-10-25 12:37:24', NULL, NULL, NULL),
(20, 14, 248423167, '2022-10-21', '21:51:00', '', '2022-10-26 19:49:49', NULL, NULL, NULL),
(21, 14, 203473271, '2022-10-21', '21:51:00', '', '2022-10-26 20:17:40', NULL, NULL, NULL),
(22, 14, 826441200, '2022-10-21', '21:51:00', '', '2022-10-26 20:19:48', NULL, NULL, NULL),
(23, 14, 780827735, '2022-10-21', '21:51:00', '', '2022-10-26 20:19:55', NULL, NULL, NULL),
(24, 14, 191539723, '2022-10-05', '13:20:00', '', '2022-10-26 20:20:17', NULL, NULL, NULL),
(25, 14, 898728618, '2022-10-27', '12:22:00', '', '2022-10-26 20:21:00', NULL, NULL, NULL),
(26, 14, 463636798, '2022-10-27', '00:26:00', '', '2022-10-26 20:24:44', NULL, NULL, NULL),
(27, 14, 393549241, '2022-10-27', '00:26:00', '', '2022-10-26 20:25:38', NULL, NULL, NULL),
(28, 14, 803979537, '2022-10-27', '12:28:00', '', '2022-10-26 20:26:15', NULL, NULL, NULL),
(29, 14, 825772155, '2022-10-27', '12:00:00', '', '2022-10-26 20:58:10', NULL, NULL, NULL),
(30, 14, 245644702, '2022-10-27', '12:00:00', '', '2022-10-26 20:58:45', NULL, NULL, NULL),
(31, 14, 598552668, '2022-10-27', '13:02:00', '', '2022-10-26 21:00:43', NULL, NULL, NULL),
(32, 14, 915741417, '2022-10-27', '13:02:00', '', '2022-10-26 21:03:06', NULL, NULL, NULL),
(33, 14, 541464983, '2022-10-26', '00:05:00', '', '2022-10-26 21:04:50', NULL, NULL, NULL),
(34, 14, 142728147, '2022-10-27', '13:10:00', '', '2022-10-26 21:08:29', NULL, NULL, NULL),
(35, 14, 518205839, '2022-10-27', '23:27:00', '', '2022-10-26 21:26:03', NULL, NULL, NULL),
(36, 14, 278955713, '2022-10-28', '00:39:00', '', '2022-10-27 08:38:20', NULL, NULL, NULL),
(37, 14, 315516217, '2022-10-28', '11:17:00', '', '2022-10-27 09:13:36', NULL, NULL, NULL),
(38, 14, 944400985, '2022-10-05', '23:00:00', '', '2022-10-29 18:57:53', NULL, NULL, NULL),
(39, 14, 105877025, '2022-10-30', '12:43:00', '', '2022-10-29 19:40:34', 'accepted', 'Selected', '2022-10-29 19:45:35'),
(40, 14, 178323970, '2022-10-30', '22:18:00', '', '2022-10-29 20:16:00', NULL, NULL, NULL),
(41, 14, 218575612, '2022-10-23', '13:37:00', '', '2022-10-29 20:34:38', NULL, NULL, NULL),
(42, 14, 654099622, '2022-10-27', '23:24:00', '', '2022-10-31 18:21:19', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `ID` int(10) NOT NULL,
  `FirstName` varchar(200) DEFAULT NULL,
  `LastName` varchar(200) DEFAULT NULL,
  `Phone` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `IsRead` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`ID`, `FirstName`, `LastName`, `Phone`, `Email`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(7, 'ipfi', 'Tshiswaise', 793571494, 'Tshiswaise26@gmail.com', '4gtf3eqws', '2022-10-26 20:26:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--

CREATE TABLE `tblinvoice` (
  `id` int(11) NOT NULL,
  `Userid` int(11) DEFAULT NULL,
  `ServiceId` int(11) DEFAULT NULL,
  `BillingId` int(11) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinvoice`
--

INSERT INTO `tblinvoice` (`id`, `Userid`, `ServiceId`, `BillingId`, `PostingDate`) VALUES
(20, 12, 23, 181559612, '2022-10-27 08:49:06'),
(21, 12, 21, 291403523, '2022-10-29 19:45:58'),
(22, 12, 21, 853926597, '2022-10-30 08:58:36'),
(23, 12, 22, 552604904, '2022-10-30 12:44:31'),
(24, 14, 23, 380821028, '2022-10-30 12:48:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` date DEFAULT NULL,
  `Timing` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `Timing`) VALUES
(1, 'aboutus', 'About Us', ' Our main focus is on quality and hygiene. Our Magic Barbershop is well equipped with advanced technology equipments and provides best quality services. Our 5 best barbers are well trained and experienced, offering advanced services in  Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the Magic are, apart from regular bleachings and Facials, many types of hairstyles.', NULL, NULL, NULL, ''),
(2, 'contactus', 'Contact Us', '                                Calderwood Street 23 shop number8, Queenstown, eastern cape , 5320', 'infomagicbarber@gmail.com', 619822638, NULL, '12:00 am to 5:00 pm');

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

CREATE TABLE `tblservices` (
  `ID` int(10) NOT NULL,
  `ServiceName` varchar(200) DEFAULT NULL,
  `ServiceDescription` mediumtext DEFAULT NULL,
  `Cost` int(10) DEFAULT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblservices`
--

INSERT INTO `tblservices` (`ID`, `ServiceName`, `ServiceDescription`, `Cost`, `Image`, `CreationDate`) VALUES
(19, 'Hair Bleaching', 'other colours', 260, 'bcfebc3539c6787b92ebce1da39c54ed1665660985.jpg', '2022-10-13 11:36:25'),
(20, 'locks Styling', 'styling ', 150, '48bdb4c058f0e2aec4dd159b01e34f6a1665661066.jpg', '2022-10-13 11:37:46'),
(21, 'Dreadlocks crotching', 'crotching', 250, 'cbdc44530f533b22295e658257e8e30f1665661111.jpg', '2022-10-13 11:38:31'),
(22, 'Hair Cut', 'Basic HairCut', 60, 'c3e4d8276076ccfc2f3d6be49a06ce941665661174.jpg', '2022-10-13 11:39:34'),
(23, 'Dreadlocks Start', 'start', 300, '48bdb4c058f0e2aec4dd159b01e34f6a1666816643.jpg', '2022-10-26 20:37:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `ID` int(10) NOT NULL,
  `FirstName` varchar(120) DEFAULT NULL,
  `LastName` varchar(250) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`ID`, `FirstName`, `LastName`, `MobileNumber`, `Email`, `Password`, `RegDate`) VALUES
(12, 'ipfi', 'Tshiswaise', 793571494, 'Tshiswaise26@gmail.com', '7fc6152df0e4329fc81dfa470ef72473', '2022-10-12 22:24:48'),
(13, 'swike', 'Tshiswaise', 727217240, 'ipfiipfi@gmail.com', '85ca66f89a1dea312f5ae05f419ccc5f', '2022-10-13 08:50:51'),
(14, 'ipfi', 'Tshiswaiseisee', 727217214, 'ipfiipfi12@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2022-10-13 12:46:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblservices`
--
ALTER TABLE `tblservices`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbook`
--
ALTER TABLE `tblbook`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblservices`
--
ALTER TABLE `tblservices`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
