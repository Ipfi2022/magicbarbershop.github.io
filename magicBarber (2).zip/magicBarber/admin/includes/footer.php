<!--footer-->
    <div class="footer">
       <p>&copy; 2022 Magic Admin Panel.</p>
    </div>
        <!--//footer-->